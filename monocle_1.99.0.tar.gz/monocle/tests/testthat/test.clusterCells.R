library(HSMMSingleCell)
library(monocle)
context("clusterCells")

test_that("clusterCells() properly validates its input",{
  
})