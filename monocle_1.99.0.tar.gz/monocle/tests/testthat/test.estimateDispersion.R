library(HSMMSingleCell)
library(monocle)
context("estimateDispersion")


test_that("estimateDispersion() properly validates its input",{
  
})