library(HSMMSingleCell)
library(monocle)
context("clusterGenes")

test_that("clusterGenes() properly validates its input",{
  
})