library(HSMMSingleCell)
library(monocle)
context("fitModels")

test_that("fitModels() properly validates its input",{
  
})

