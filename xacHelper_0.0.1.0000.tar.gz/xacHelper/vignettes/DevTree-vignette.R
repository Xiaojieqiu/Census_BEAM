% \VignetteIndexEntry{xacjHelper: helper package for manuscript: Analyzing branched single-cell trajectories uncovers regulators of cell fate decisions.} 
% \VignetteEngine{knitr::knitr}
% \VignetteDepends{} 
% \VignettePackage{xacjHelper}
\documentclass[10pt,oneside]{article}

\newcommand{\thetitle}{Analyzing branched single-cell trajectories uncovers regulators of cell fate decisions}

%\usepackage[pdftitle={\thetitle},pdfauthor={Wolfgang Huber}]{whbiocvignette}
\usepackage{whbiocvignette}
% \usepackage{times}
%\usepackage{hyperref}
%\usepackage{verbatim}
%\usepackage{graphicx}
%\usepackage{fancybox}
%\usepackage{color}

\title{\textsf{\textbf{\thetitle}}}
\author{Xiaojie Qiu\\[1em]University of Washington,\\ Seattle, Washington, USA\\
  \texttt{xqiu@uw.edu} 
  \and
  \author{Andrew Hill\\[1em]University of Washington,\\ Seattle, Washington, USA\\
    \texttt{ajh24@uw.edu } 
    \and
    \author{Cole Trapnell\\[1em]University of Washington,\\ Seattle, Washington, USA\\
      \texttt{coletrap@uw.edu} }
    
    \begin{document}
    \SweaveOpts{concordance=TRUE}
    
    <<include=FALSE, eval=TRUE>>=
      library(monocle)
    library(xacHelper)
    library(igraph)
    load_all_libraries()
    
    load('/Users/xqiu/Dropbox (Personal)/Quake/project_package/DevTree/redo-analysis/submission/.RData')
    elife_directory = './'
    @ %def
    
    \maketitle
    
    \begin{abstract}
    This vigenetee is an accompanying file for the paper "Analyzing branched single-cell trajectories uncovers regulators of cell fate decisions". All figures in the paper can be generated through this vigenettee. For more details about those figures, especially the methodologies behind them, please refer to the paper \cite{xiaojie_cole}
    \end{abstract}
    
    \tableofcontents
    
    \section{Introduction}
    In order to ensure the reproducibility of our work, we provide detailed R code to give all the figures presented in the paper based on function from this package. For the sake of time, we load the pre-computated objects but we also provides the script that can be used to generate the same data (see the runme file).
    
    \section{Main figures}
    
    We provide the code first for making the figure presented in the main text.
    
    \subsection{Figure 1: Bronchoaveolar progenitor (BP) cells differentiate along a continuous, 
      branched trajectory into type I and type II pneumocytes.}
    
    <<generate_fig1a, eval=TRUE, fig.width = 4, fig.height = 4>>=
      markers <- c('Pdpn', 'Sftpb', 'Ccnb2', 'Cdk1')
    abs_AT12_cds_subset_all_gene@reducedDimS <- AT12_cds_subset_all_gene@reducedDimS
    abs_AT12_cds_subset_all_gene@reducedDimA <- AT12_cds_subset_all_gene@reducedDimA
    abs_AT12_cds_subset_all_gene@reducedDimK <- AT12_cds_subset_all_gene@reducedDimK
    abs_AT12_cds_subset_all_gene@reducedDimW <- AT12_cds_subset_all_gene@reducedDimW
    abs_AT12_cds_subset_all_gene@minSpanningTree <- AT12_cds_subset_all_gene@minSpanningTree
    
    plot_spanning_tree(abs_AT12_cds_subset_all_gene, color_by="Time", show_backbone=T, backbone_color = 'black',
                       markers=markers, show_cell_names = F, show_all_lineages = T, cell_link_size = 0.2) + 
      scale_size(range = c(0.1, 2.5)) + nm_theme()
    
    @ %def 
    
    <<generate_fig1b, eval=TRUE, fig.width = 4, fig.height = 4>>=
      example_ids <- row.names(subset(fData(absolute_cds), gene_short_name %in% 
                                        markers))
    new_cds <- buildLineageBranchCellDataSet(abs_AT12_cds_subset_all_gene[1:10, ], lineage_labels = c('AT1', 'AT2'))
    
    colour_cell <- rep(0, length(new_cds$Lineage))
    names(colour_cell) <- as.character(new_cds$Time)
    colour_cell[names(colour_cell) == 'E14.5'] <- "#7CAF42"
    colour_cell[names(colour_cell) == 'E16.5'] <- "#00BCC3"
    colour_cell[names(colour_cell) == 'E18.5'] <- "#A680B9"
    colour_cell[names(colour_cell) == 'Adult'] <- "#F3756C"
    
    colour <- rep(0, length(new_cds$Lineage))
    names(colour) <- as.character(new_cds$Lineage)
    colour[names(colour) == 'AT1'] <- AT1_Lineage
    colour[names(colour) == 'AT2'] <- AT2_Lineage
    
    plot_genes_branched_pseudotime2(abs_AT12_cds_subset_all_gene[example_ids, ], cell_color_by = "Time", trajectory_color_by = "Lineage", fullModelFormulaStr = '~sm.ns(Pseudotime, df = 3)*Lineage', normalize = F, stretch = T, lineage_labels = c('AT1', 'AT2'), cell_size = 1, ncol = 2) + nm_theme()+ ylab('Transcript counts')
    
    @ %def 
    
    \subsection{Figure 2: BEAM framework for detecting lineage-dependent genes.}
    <<generate_fig2b, eval=TRUE, fig.width = 4, fig.height = 4>>=
      fig2_genes <- c("Ager", "Sftpb", 'Hprt', 'Pgk1')#, 'Ubc', 'Rpl5', 'Puf60', 'Nucb2')
    fig2_genes_ids <- row.names(subset(fData(absolute_cds), gene_short_name %in% 
                                         fig2_genes))
    
    colour_cell <- rep(0, length(new_cds$Lineage))
    names(colour_cell) <- as.character(new_cds$State)
    colour_cell[names(colour_cell) == '1'] <- prog_cell_state
    colour_cell[names(colour_cell) == '2'] <- AT1_Lineage
    colour_cell[names(colour_cell) == '3'] <- AT2_Lineage
    
    colour <- rep(0, length(new_cds$Lineage))
    names(colour) <- as.character(new_cds$Lineage)
    colour[names(colour) == 'AT1'] <- AT1_Lineage
    colour[names(colour) ==  'AT2'] <- AT2_Lineage
    
    plot_genes_branched_pseudotime2(abs_AT12_cds_subset_all_gene[fig2_genes_ids, ], color_by = "Time", panel_order = fig2_genes, 
                                    trajectory_color_by = "Lineage", fullModelFormulaStr = '~sm.ns(Pseudotime, df = 3)*Lineage', reducedModelFormulaStr = '~sm.ns(Pseudotime, df = 3)', 
                                    normalize = T, stretch = T, lineage_labels = c('AT1', 'AT2'), cell_size = 1, ncol = 2) + nm_theme()+ ylab('Transcript counts')
    %def 
    
    <<generate_fig2c, eval=TRUE, fig.width = 4, fig.height = 4>>=
      abs_str_logfc_df_list <- calILRs(cds = abs_AT12_cds_subset_all_gene[add_quake_gene_all_marker_ids, ], lineage_states = c(2, 3), stretch = T,cores = 1, 
                                       trend_formula = "~sm.ns(Pseudotime, df = 3) * Lineage", ILRs_limit = 3, 
                                       relative_expr = T, weighted = T, label_by_short_name = F, 
                                       useVST = T, round_exprs = FALSE, pseudocount = 0, output_type = "all", file = "str_logfc_df", return_all = T)
    
    #make the plot for the comparing of the bifurcation timing: 
    abs_bifurcation_time <- detectBifurcationPoint(abs_str_logfc_df_list$str_norm_div_df[, ], ILRs_threshold = 0.3)
    names(abs_bifurcation_time) <- fData(abs_AT12_cds_subset_all_gene[row.names(abs_str_logfc_df_list$str_norm_div_df), ])$gene_short_name
    abs_valid_bifurcation_time  <- abs_bifurcation_time[!is.na(abs_bifurcation_time)]
    abs_valid_bifurcation_time <- abs_valid_bifurcation_time[unique(names(abs_valid_bifurcation_time))]
    
    abs_bif_df <- data.frame(bifurcation_time_point = abs_bifurcation_time[c(AT1_early, AT1_late, AT2_early, AT2_late)], 
                             type = c(rep("AT1 early", length(AT1_early)), 
                                      rep("AT1 late", length(AT1_late)), 
                                      rep("AT2 early", length(AT2_early)), 
                                      rep("AT2 late", length(AT2_late))))
    # std_bif_df$type <- apply(str_split_fixed(std_bif_df$type, "_", 2), 1, paste, collapse = " " )
    timing_example_ids <- row.names(subset(fData(absolute_cds), gene_short_name %in% 
                                             c(AT1_early, AT1_late, AT2_early, AT2_late)))
    
    abs_marker_genes_branch_pval <- branchTest(abs_AT12_cds_subset_all_gene[add_quake_gene_all_marker_ids, ], cores = 1, relative_expr = T, weighted = F)
    # std_marker_genes_branch_pval <- branchTest(std_AT12_cds_subset_all_gene[add_quake_gene_all_marker_ids, ], cores = 1, relative_expr = F, weighted = F)
    
    valid_timing_id <- timing_example_ids[abs_marker_genes_branch_pval[timing_example_ids, 'qval'] < 0.01]
    
    abs_bif_df <- abs_bif_df[!is.na(abs_bif_df$bifurcation_time_point), ]
    data <- subset(abs_bif_df, abs(bifurcation_time_point) > 27)
    data <- data[as.character(fData(absolute_cds[valid_timing_id, ])$gene_short_name), ]
    data <- subset(data, !is.na(type))
    
    qplot(type, abs(bifurcation_time_point), color = type, geom = c('jitter', 'boxplot'), data = data, alpha = I(0.7)) + 
      xlab('') + ylab('bifurcation time point') + #geom_boxplot(stat = "identity", aes(ymin = `0%`, lower = `25%`, middle = `50%`, upper = `75%`, ymax = `100%`)) 
      nm_theme()
    %def 
    
    <<generate_fig2d, eval=TRUE, fig.width = 4, fig.height = 4>>=
      add_quake_gene_all_marker_ids_branchTest_res <- relative_abs_AT12_cds_subset_all_gene[add_quake_gene_all_marker_ids, ]
    valid_add_quake_gene_all_marker_ids <- row.names(subset(add_quake_gene_all_marker_ids_branchTest_res, qval < 0.1))
    
    jet.colors <- colorRampPalette(c("#4F64AD", "#F6F7FB", "#F2991F"))
    bk <- seq(-3.1,3.1, by=0.1)
    hmcols <- jet.colors(length(bk) - 1)
    
    valid_add_quake_gene_all_marker_ids_res_no_fit_log <- plot_genes_branched_heatmap(abs_AT12_cds_subset_all_gene[add_quake_gene_all_marker_ids, ], num_clusters=4, norm_method = "log", use_fitting_curves = F, scaling = F, hmcols = hmcols, file_name = paste(elife_directory, 'eLife_fig2d.pdf'))
    valid_add_quake_gene_all_marker_ids_res_FIT_log <- plot_genes_branched_heatmap(abs_AT12_cds_subset_all_gene[add_quake_gene_all_marker_ids, ], num_clusters=4, norm_method = "log", use_fitting_curves = T, scaling = F, hmcols = hmcols, file_name = paste(elife_directory, 'eLife_fig2d.1.pdf'))
    
    #add the AT1/2 early/late annotation: 
    add_annotation_row[fData(absolute_cds[timing_example_ids, ])$gene_short_name, 1]
    
    add_annotation_row <- data.frame(annotation_time = c(rep("AT1_early", length = length(AT1_early)), rep("AT1_late", length = length(AT1_late)), 
                                                         rep("AT2_early", length = length(AT2_early)), rep("AT2_late", length = length(AT2_late))), row.names = c(AT1_early, AT1_late, AT2_early, AT2_late))
    
    time_annotated_heatmap <- plot_genes_branched_heatmap(abs_AT12_cds_subset_all_gene[row.names(add_annotation_row), ], num_clusters=4, norm_method = "log", use_fitting_curves = F, scaling = F, hmcols = hmcols, add_annotation_row = add_annotation_row, file_name = paste(elife_directory, 'eLife_fig2d_annotation.pdf'), show_rownames = T, use_gene_short_name = T)
    
    %def 
    
    \subsection{Figure 3: Use of transcript counts improves accuracy of Differential expression analysis and can be performed on libraries with or without spike controls}
    <<generate_fig3a, eval=TRUE, fig.width = 4, fig.height = 4>>=
      transcript_num <- 38919
    test <- exprs(absolute_cds)[1:38919, ] #filter out the spike-in trnascripts
    mode <-apply(test, 2, function(x) mlv(round(x)[round(x) > .1], method = "mfv")$M) #calculate the mode of transcript counts
    ggplot(data = data.frame(mode = mode), aes(x = mode)) + geom_bar(fill = I('red'), size = .5) + geom_vline(x = 1, linetype = 'longdash', color = I('blue'), size = .2) + 
      xlab('Mode of transcript counts') + ylab('Cells') + scale_x_continuous(breaks = 1:10) + monocle_theme_opts() + nm_theme() #make figure 1.a
    
    mode_df <- data.frame(mode = estimate_t(absolute_cds), Time = pData(absolute_cds)$Time)
    ggplot(aes(x = mode), data = mode_df) + geom_bar(fill = I('red'), size = .5) + 
      geom_vline(x = 1, linetype = 'longdash', color = I('blue'), size = .2) + facet_wrap(~ Time, scales = 'free') + 
      xlab('Mode of transcript counts') + ylab('Cells') + scale_x_continuous(breaks = 1:10) + monocle_theme_opts() + nm_theme() #make figure 1.a
    %def 
    
    <<generate_fig3b, eval=TRUE, fig.width = 4, fig.height = 4>>=
      test <- mapply(function(cell_dmode, model) {
        predict(model, newdata = data.frame(log_fpkm = log10(cell_dmode)), type = 'response')
      }, as.list(estimate_t(exprs(isoform_count_cds)[1:119469, ])), molModels_select)
    
    df <- pData(absolute_cds)
    df$mode_transcript <- 10^test
    df$estimate_mode <- estimate_t(exprs(isoform_count_cds))
    
    #make figure 3b
    qplot(ceiling(mode_transcript), fill = I('red'), data = df) + geom_vline(x = 1, linetype = 'longdash', color = I('blue'), size = .1) + xlab('Transcript count for most frequent log10(FPKM)') + ylab('Cells') + nm_theme()
    %def
    
    <<generate_fig3c, eval=TRUE, fig.width = 4, fig.height = 4>>=
      kb_df <- t(rbind.data.frame(lapply(molModels, function(x) c(b = coef(x)[1], k = coef(x)[2]))))
    colnames(kb_df) <- c('b', 'k')
    
    qplot(k, b, geom = c('point'), size = I(4), data = as.data.frame(kb_df), color = pData(absolute_cds)$Time) + #label = Cell,
      geom_smooth(method = 'rlm', aes(group = 199), size = .1)  + 
      xlab('Slope from FPKM vs. \n ERCC transcript counts') + ylab('Intercept from  FPKM vs. \n ERCC transcript counts')
    %def 
    
    <<generate_fig3e, eval=TRUE, fig.width = 4, fig.height = 4>>=
      optimization_matrix<- do.call(rbind.data.frame, optimization_landscape_3d)
    
    optimization_matrix_filt <- subset(optimization_matrix, is.nan(optim_res) == FALSE & is.finite(optim_res))
    max_optim_score <- 3
    optimization_matrix_filt$optim_res[optimization_matrix_filt$optim_res > max_optim_score] <- max_optim_score
    
    spdf <- SpatialPointsDataFrame( data.frame( x = optimization_matrix_filt$m , y = optimization_matrix_filt$c ) , data = data.frame( z = optimization_matrix_filt$optim_res ) )
    
    # Make an evenly spaced raster, the same extent as original data
    e <- extent( spdf )
    
    # Determine ratio between x and y dimensions
    ratio <- ( e@xmax - e@xmin ) / ( e@ymax - e@ymin )
    
    # Create template raster to sample to
    r <- raster( nrows = 56 , ncols = floor( 56 * ratio ) , ext = extent(spdf) )
    rf <- rasterize( spdf , r , field = "z" , fun = mean )
    
    # We can then plot this using `geom_tile()` or `geom_raster()`
    rdf <- data.frame( rasterToPoints( rf ) )
    
    optimal_solution <- head(arrange(optimization_matrix_filt, optim_res), 1)
    ggplot( NULL ) + geom_raster( data = rdf , aes( x , y , fill = log10(layer) ) ) + 
      annotate("text", x = -3.85, y = 3.1, label = "True (m,c)", color="magenta", size=2) + 
      annotate("point", x = -4.277778, y = 2.932929, color="magenta", size = 1) + 
      #annotate("text", x = -3.7, y = 3.2, label = "True (m,c)") + 
      annotate("text", x = -5.1, y = 2.7, label = "Algorithm (m,c)", color="red", size=2) + 
      annotate("point", x = optimal_solution$m, y = optimal_solution$c, color="red", size=1) + 
      scale_fill_gradientn(guide=guide_legend(title=expression(paste(log[10](F)))), colours=brewer.pal(name="YlGnBu", n=7)) +
      xlab("m") + ylab("c") +
      theme(strip.background = element_rect(colour = 'white', fill = 'white')) +
      theme(panel.border = element_blank(), axis.line = element_line()) +
      theme(panel.grid.minor.x = element_blank(), panel.grid.minor.y = element_blank()) +
      theme(panel.grid.major.x = element_blank(), panel.grid.major.y = element_blank()) + scale_size(range = c(0.1, 2)) + 
      theme(panel.background = element_rect(fill='white')) + nm_theme()
    %def 
    
    <<generate_fig3f, eval=TRUE, fig.width = 4, fig.height = 4>>=
      qplot(pData(absolute_cds)$endogenous_RNA[pData(absolute_cds)$endogenous_RNA > 1e3], 
            pData(mc_adj_cds)$endogenous_RNA[pData(absolute_cds)$endogenous_RNA > 1e3], log="xy", color=pData(absolute_cds)$Time[pData(absolute_cds)$endogenous_RNA > 1e3], size = I(1)) + 
      geom_smooth(method="lm", color="black", size = .1) + geom_abline(color="red") +  
      xlab("Total endogenous mRNA \n (spike-in)") +
      ylab("Total endogenous mRNA \n (spike-in free algorithm)") + #scale_size(range = c(0.25, 0.25)) + 
      scale_color_discrete(name = "Time points") + nm_theme()
    %def 
    
    <<generate_fig3g, eval=TRUE, fig.width = 4, fig.height = 4>>=
      Time <- pData(abs_AT12_cds_subset_all_gene)$Time
    E14.5_cell <- rowMeans(exprs(abs_AT12_cds_subset_all_gene[, which(Time == 'E14.5')]))
    E16.5_cell <- rowMeans(exprs(abs_AT12_cds_subset_all_gene[, which(Time == 'E16.5')]))
    E18.5_cell <- rowMeans(exprs(abs_AT12_cds_subset_all_gene[, which(Time == 'E18.5')]))
    Adult_cell <- rowMeans(exprs(abs_AT12_cds_subset_all_gene[, which(Time == 'Adult')]))
    
    mc_E14.5_cell <- rowMeans(exprs(mc_adj_cds[, colnames(abs_AT12_cds_subset_all_gene)[which(Time == 'E14.5')]]))
    mc_E16.5_cell <- rowMeans(exprs(mc_adj_cds[, colnames(abs_AT12_cds_subset_all_gene)[which(Time == 'E16.5')]]))
    mc_E18.5_cell <- rowMeans(exprs(mc_adj_cds[, colnames(abs_AT12_cds_subset_all_gene)[which(Time == 'E18.5')]]))
    mc_Adult_cell <- rowMeans(exprs(mc_adj_cds[, colnames(abs_AT12_cds_subset_all_gene)[which(Time == 'Adult')]]))
    
    mc_abs_exprs_df <- data.frame(spikein = as.vector(c(E14.5_cell, E16.5_cell, E18.5_cell, Adult_cell)), 
                                  mc_algorithm = as.vector(c(mc_E14.5_cell, mc_E16.5_cell, mc_E18.5_cell, mc_Adult_cell)),
                                  cell = rep(c("E14.5_cell", "E16.5_cell", "E18.5_cell", "Adult_cell"), each = nrow(mc_adj_cds)))
    
    qplot(spikein + 1, mc_algorithm + 1, log = 'xy', 
          color = cell, alpha = 0.8, data = mc_abs_exprs_df, size  = 1.5) + facet_wrap(~cell, scales = 'free', ncol = 2) + #  geom_smooth(method = 'rlm', aes(group = 199), size = .1) + 
      scale_size(range = c(1.5, 1)) +  geom_abline() + xlab('Transcript counts (Spike-in)') + scale_size(range = c(0.25, 0.25)) + 
      ylab('Transcript counts (Recovery algorithm)') + nm_theme()
    %def 
    
    <<generate_fig3h, eval=TRUE, fig.width = 4, fig.height = 4>>=
      mc_spikein_df <- plot_pre_rec_f1(test_p_list = list(mode_size_norm_permutate_ratio_by_geometric_mean = new_abs_size_norm_monocle_p_ratio_by_geometric_mean,
                                                          mc_mode_size_norm_permutate_ratio_by_geometric_mean = new_mc_size_norm_monocle_p_ratio_by_geometric_mean),
                                       permutate_pval = list(mode_size_norm_permutate_ratio_by_geometric_mean = mode_size_norm_permutate_ratio_by_geometric_mean,
                                                             mc_mode_size_norm_permutate_ratio_by_geometric_mean = mc_mode_size_norm_permutate_ratio_by_geometric_mean),
                                       row.names(absolute_cds), #gene_list, overlap_genes, high_gene_list
                                       return_df = T, #na.rm = T, 
                                       p_thrsld = 0.01, #0.05
                                       rownames = c('monocle (New size normalization)', 'monocle (New size normalization, Estimate transcript)'))
    mc_spikein_df$data_type = c("Spikein transcripts", "estimated transcripts")
    
    mc_spikein_df[, 'Type'] <- c('Monocle', 'Monocle') # geom_bar(stat = 'identity', position = 'dodge') 
    colnames(mc_spikein_df)[1:3] <- c('Precision', 'Recall', 'F1 score')
    
    ggplot(aes(factor(Type), value,  fill = data_type), data = melt(mc_spikein_df)) + geom_bar(position = position_dodge(), stat = 'identity') + #facet_wrap(~variable) + 
      ggtitle(title) + scale_fill_discrete('Type') + xlab('Type') + ylab('') + facet_wrap(~variable, scales = 'free_x') +  theme(axis.text.x = element_text(angle = 30, hjust = .9)) + 
      ggtitle('') + theme(strip.text.x = element_blank(), strip.text.y = element_blank()) + theme(strip.background = element_blank()) + nm_theme() + xlab('') + theme(axis.text.x=element_blank(), axis.ticks.x=element_blank())
    
    %def 
    
    \subsection{Figure 4: BEAM identifies coherent clusters of branching expression dynamics and reveals potential drivers for lineage bifurcation.}
    <<generate_fig4b, eval=TRUE, fig.width = 4, fig.height = 4>>=
      branch_gene_str_norm_div_df <- abs_AT12_cds_subset_all_gene_ILRs_list$str_logfc_df[row.names(relative_abs_AT12_cds_subset_all_gene[relative_abs_AT12_cds_subset_all_gene[, 'qval'] <= 0.05, ]), ]
    branch_genes <- row.names(subset(relative_abs_AT12_cds_subset_all_gene, qval <= 0.05))
    
    fData(abs_AT12_cds_subset_all_gene)$num_cell_expressed <- esApply(abs_AT12_cds_subset_all_gene[, ], 1, function(x) sum(round(x) > 0))
    valid_expressed_genes <- row.names(subset(fData(abs_AT12_cds_subset_all_gene), num_cell_expressed > 5))
    
    all_AT12_heatmap <- plot_genes_branched_heatmap(abs_AT12_cds_subset_all_gene[branch_genes[branch_genes %in% valid_expressed_genes], ], 
                                                    stretch = T, file_name = paste(elife_directory, "eLife_fig3b.pdf", sep = ''))
    
    clusters <- as.numeric(all_AT12_heatmap$annotation_row$Cluster); 
    names(clusters) <- fData(abs_AT12_cds_subset_all_gene[row.names(all_AT12_heatmap$annotation_row), ])$gene_short_name
    
    branchGenes_gsa_results_branch_genes <- collect_gsa_hyper_results(abs_AT12_cds_subset_all_gene[row.names(branch_gene_str_norm_div_df), ], mouse_go_gsc, clusters)
    
    %def 
    
    <<generate_fig4c, eval=TRUE, fig.width = 4, fig.height = 4>>=
      motif_TFs <- c("ELF1", "EWSR1", "FLI1", "RAR", "BACH1", "STAT5A", "PPARG", "STAT5B", "SOX2", "TCFE2A", "RXR", "ARNT", "GATA1", "NR1H2", "BATF", "VDR", "MAX", "TAL1", "FOS", "HAND1", "POU5F1", "TCF3", "MYC", "TLX1", "NR1H3", "CEBPA", "MAF", "NFE2", "RXRA", "SMAD4", "SMAD3", "SMAD2", "MAFK", "STAT1", "DDIT3", "STAT2", "HIF1A", "JUN", "NFIC",  "HSF1", "RFX1", "SPI1", "MEF2C", "MYOD1", "MEF2A", "CDX2", "FOXO1", "TBP", "RORA", "REST", "NR2E3", "FOXO3", "GATA1", "GATA2", "ATOH1", "HOXC9", "FLI1", "GATA3", "GATA4", "FOXF2", "RREB1", "YY1", "RELA", "RXRA", "GABPA", "HNF4G", "MECOM", "JUNB", "HNF4A", "JUN", "TFAP2A", "NFE2L2", "PRDM1", "TFAP2C", "SOX3", "SOX2", "ELK1", "SOX6", "SOX9", "SRF", "MEIS1", "NR2C2", "FOXH1", "SRY", "T", "FOXQ1", "HOXA5", "ELK4", "LHX3", "JUND", "NKX3-2", "HOXA9", "NKX3-1", "BHLHE40", "RUNX1", "DUX4", "NKX2-5", "RUNX2", "TCF3", "PLAG1", "SREBF1", "KLF5", "MAFF", "ESRRA", "ESRRB", "RFX5", "MAFB", "FOXA1", "NR4A2", "TEAD1", "EN1", "MAFK", "USF1", "FOXP1", "BRCA1", "USF2", "FOXP2", "SREBF2", "NRF1", "ETS1", "EBF1", "RFX1", "MZF1", "RFX2", "KLF1", "FOXI1", "TCF12", "KLF4", "E2F1", "HLF", "ZBTB33", "HNF1B", "E2F3", "ELF1", "FOSL2", "HNF1A", "E2F4", "FOXA2", "E2F6", "ELF5", "PPARG", "PAX6", "SPI1", "PAX5", "TP63", "PAX4", "NFKB1", "CTCF", "ZEB1", "PAX2", "FEV", "CRX", "FOS", "MAX", "GFI1B", "HSF1", "NOBOX", "SPIB", "SOX17", "NFIL3", "MYB", "FOSL1", "MYC", "NR2F1", "EGR1", "ZFP423", "AR", "EGR2", "ZFX", "ESR1", "TP53", "ESR2", "ZNF143", "HLTF", "MYCN", "FOXC1", "SPZ1", "NFYB", "EHF", "NFYA", "NR3C1", "TCF7L2", "TCFCP2L1", "STAT6", "STAT4", "REL", "POU2F2", "HINFP", "BCL6", "MYOG", "THAP1", "GFI1", "NFATC2", "FOXD1", "FOXD3", "CEBPA", "INSM1", "ZNF263", "ERG", "CEBPB", "FOXL1", "CREB1", "STAT1", "STAT3", "SP1", "SP2", "IRF1", "IRF2", "PBX1", "NR5A2", "NHLH1")
    motif_TFs_add <- c("RARA", "E2A", "TRP63", "TRP53", "ZFP143", "TFCP2L1")
    
    motif_Tfs_id <- row.names(subset(fData(absolute_cds[, ]), toupper(gene_short_name) %in% c(motif_TFs, motif_TFs_add)))
    
    #genes are not shown in the gene_short_name: 
    setdiff(motif_TFs, toupper(fData(absolute_cds)$gene_short_name))
    
    TF_5k_enrichment_gsc <- loadGSCSafe("Lung_JASPAR_5kb_hits_olap.gmt", encoding="latin1") 
    
    valid_gene_id_cell_new <- row.names(absolute_cds[which(rowSums(exprs(standard_cds) >= 1) > 4), ])
    valid_cell_genes_TF_enrichment_results_5k <- collect_gsa_hyper_results(abs_AT12_cds_subset_all_gene[valid_gene_id_cell_new, ], TF_5k_enrichment_gsc, clusters)
    hyper_df <- plot_gsa_hyper_heatmap(abs_AT12_cds_subset_all_gene[valid_gene_id_cell_new, ], valid_cell_genes_TF_enrichment_results_5k, significance = 1e-2)
    
    load('hyper_df')
    
    hyper_df[, 'first'] <- str_split_fixed(hyper_df[, 1], "::", 2)[,1]
    hyper_df[, 'second'] <- str_split_fixed(hyper_df[, 1], "::", 2)[,2]
    
    valid_gene_id_20_cell <- row.names(absolute_cds[which(rowSums(exprs(standard_cds) >= 1) > 40), ])
    valid_hyper_df <- subset(hyper_df, (toupper(first) %in% toupper(fData(abs_AT12_cds_subset_all_gene[valid_gene_id_20_cell, ])$gene_short_name)) | 
                               (toupper(second) %in% toupper(fData(abs_AT12_cds_subset_all_gene[valid_gene_id_20_cell, ])$gene_short_name))
    ) 
    
    valid_hyper_df$sig <- T
    cluster_color <- c('#E52027' = '#E52027', '#357EB9' = '#357EB9', '#4BAE49' = '#4BAE49', '#974F9F' = '#974F9F', '#F47D20' = '#F47D20', '#F6EE38' = '#F6EE38')
    valid_hyper_df$cluster_color <- cluster_color[as.numeric(valid_hyper_df$cluster_id)]
    
    qplot(cluster_id, gene_set, fill=cluster_color, geom="tile", data=valid_hyper_df) + nm_theme() + scale_fill_manual(values=cluster_color)  + 
      theme(axis.text.x = element_text(angle = 0, hjust = 1)) + xlab('') + ylab('')
    %def 
    
    <<generate_fig4d, eval=TRUE, fig.width = 4, fig.height = 4>>=
      names(colour_cell) <- as.character(new_cds$State)
    colour_cell[names(colour_cell) == '1'] <- prog_cell_state
    colour_cell[names(colour_cell) == '2'] <- AT1_cell_state
    colour_cell[names(colour_cell) == '3'] <- AT2_cell_state
    
    colour <- rep(0, length(new_cds$Lineage))
    names(colour) <- as.character(pData(new_cds)$Lineage)
    colour[names(colour) == 'AT1'] <- AT1_Lineage
    colour[names(colour) ==  'AT2'] <- AT2_Lineage
    
    gene_grn_list <- infer_branch_gene_grn(TF_enrichment_gsc = TF_5k_enrichment_gsc, file = 'gene_regulatory_net_up5k', p_thrsld = 0.01)
    branch_motif_Tfs <- gene_grn_list$branch_tfs[toupper(gene_grn_list$branch_tfs) %in% toupper(valid_hyper_df$first) | 
                                                   toupper(gene_grn_list$branch_tfs) %in% toupper(valid_hyper_df$second)]
    branch_motif_Tfs_id <- row.names(subset(fData(abs_AT12_cds_subset_all_gene), toupper(gene_short_name) %in% branch_motif_Tfs)) 
    plot_genes_branched_pseudotime2(abs_AT12_cds_subset_all_gene[branch_motif_Tfs_id, ], cell_color_by = "State", 
                                    trajectory_color_by = "Lineage", fullModelFormulaStr = '~sm.ns(Pseudotime, df = 3)*Lineage', normalize = F, stretch = T,
                                    lineage_labels = c('AT1', 'AT2'), cell_size = 1, ncol = 4, reducedModelFormulaStr = "~sm.ns(Pseudotime, df=3)", add_pval = T) + 
      ylab('Transcript counts') + nm_theme()
    %def 
    
    \subsection{Figure 5: Loss-of-function trajectories branch from the immune response trajectory in BDMCs.}
    <<generate_fig5b, eval=TRUE, fig.width = 4, fig.height = 4>>=
      monocle::plot_spanning_tree(Shalek_abs_subset_ko_LPS, color_by="interaction(experiment_name, time)", cell_size=1) + 
      scale_color_manual(values=shalek_custom_color_scale_plus_states) + illustrator_theme() 
    
    %def 
    
    <<generate_fig5c, eval=TRUE, fig.width = 4, fig.height = 4>>= 
      #ko_branch_genes <- row.names(subset(ko_branching_genes, qval < 0.01))
      #ko_valid_expressed_genes <- row.names(subset(fData(Shalek_abs_subset_ko_LPS), num_cells_expressed > 5))
      
      #plot_genes_branched_heatmap(Shalek_abs_subset_ko_LPS[ko_branch_genes[ko_branch_genes %in% ko_valid_expressed_genes],], num_clusters=6, norm_method = "vstExprs", file_name=paste(elife_directory, 'figure_5C.pdf', sep = ''), cores= 1, ABC_df=Shalek_abs_subset_ko_LPS_abcs, branchTest_df=ko_branching_genes, hmcols=NULL, lineage_labels = c('Normal cells', 'Knockout cells'))
      #qplot(1:nrow(hyper_df_cluster2_order), - log10(qval), data=hyper_df_cluster2_order, geom = c('bar'), stat = 'identity', fill = 'red') + illustrator_theme() + geom_hline(yintercept = 1, linetype = 2, size  = 0.2, color = 'blue') + xlab('') #+ geom_text(aes(label = label), angle = 45, vjust = 2)
      
      Shalek_abs_subset_ko_LPS_heatmap_annotations = plot_genes_branched_heatmap(Shalek_abs_subset_ko_LPS[row.names(subset(ko_branching_genes, qval < 0.01)),], num_clusters=6, norm_method = "vstExprs", file_name=paste(elife_directory, 'figure_5C_new.pdf', sep = ''), cores=detectCores(), ABC_df=Shalek_abs_subset_ko_LPS_abcs, branchTest_df=ko_branching_genes, hmcols=NULL, lineage_labels = c('Normal cells', 'Knockout cells'))
    test = plot_genes_branched_heatmap(Shalek_abs_subset_ko_LPS[row.names(subset(ko_branching_genes, qval < 0.01)),], num_clusters=6, norm_method = "vstExprs", file_name=paste(elife_directory, 'figure_5C_test.pdf', sep = ''), cores= detectCores(), ABC_df=Shalek_abs_subset_ko_LPS_abcs, branchTest_df=ko_branching_genes, hmcols=NULL, lineage_labels = c('Normal cells', 'Knockout cells'))
    
    %def 
    
    <<generate_fig5c, eval=TRUE, fig.width = 4, fig.height = 4>>=
      #plot_genes_branched_heatmap(Shalek_abs_subset_ko_LPS[ko_branch_genes[ko_branching_genes %in% ko_valid_expressed_genes],], num_clusters=6, norm_method = "vstExprs", file_name=paste(elife_directory, 'figure_5C.pdf', sep = ''), cores= 1, ABC_df=Shalek_abs_subset_ko_LPS_abcs, branchTest_df=ko_branching_genes, hmcols=NULL, lineage_labels = c('Normal cells', 'Knockout cells'))
      
      %def 
    
    \subsection{Figure 6: Cell-cell communication via IFN-B induces a branch during the immune response in BDMCs.}
    <<generate_fig6b, eval=TRUE, fig.width = 4, fig.height = 4>>=
      monocle::plot_spanning_tree(Shalek_golgi_update, color_by="interaction(experiment_name, time)", cell_size=1) + 
      scale_color_manual(values=shalek_custom_color_scale_plus_states) + nm_theme()
    
    %def 
    
    \subsection{Figure 6: Blocking cellular secretion generates a branch in the trajectory followed by immune-stimulated dendritic cells.}
    <<generate_fig6b, eval=TRUE, fig.width = 4, fig.height = 4>>=
      
      #plot_genes_branched_heatmap(Shalek_golgi_update[golgi_branch_genes[golgi_branch_genes %in% golgi_valid_expressed_genes],], num_clusters=6, norm_method = "vstExprs", lineage_labels = c('Normal', 'Golgi Plug'), file_name=paste(elife_directory, 'figure_6C.pdf', sep = ''), cores= 1, ABC_df=Shalek_golgi_abcs, branchTest_df=golgi_branching_genes, hmcols=NULL)
      
      Shalek_golgi_update_heatmap_annotations = plot_genes_branched_heatmap(Shalek_golgi_update[row.names(subset(golgi_branching_genes, qval < 0.01)),], num_clusters=6, norm_method = "vstExprs", lineage_labels = c('Normal', 'Golgi Plug'), 
                                                                            file_name=paste(elife_directory, 'figure_6C_new.pdf', sep = ''), cores=detectCores() / 2, ABC_df=Shalek_golgi_abcs, branchTest_df=golgi_branching_genes, hmcols=NULL)
    
    %def 
    
    <<generate_fig6c, eval=TRUE, fig.width = 4, fig.height = 4>>=
      andrew_element_all <- c(
        row.names(golgi_wt_0to6_pseudo[golgi_wt_0to6_pseudo$qval < .01, ]), #0to6
        #row.names(golgi_plug0_wt4[golgi_plug0_wt4$qval < .01, ]), 
        row.names(golgi_plug0_wt0[golgi_plug0_wt0$qval < .01, ])
      )
    andrew_sets_all <- c(
      rep(paste('golgi_wt_0to6_pseudo', sep = ''), length(row.names(golgi_wt_0to6_pseudo[golgi_wt_0to6_pseudo$qval < .01, ]))),
      rep(paste('golgi_plug0_wt4', sep = ''), length(row.names(golgi_plug0_wt4[all_golgi_plug0_wt4$qval < .01, ]))),
      rep(paste('golgi_plug0_wt0', sep = ''), length(row.names(golgi_plug0_wt0[golgi_plug0_wt0$qval < .01, ])))
    )
    
    venneuler_venn(andrew_element_all, andrew_sets_all)
    %def
    
    \section{Supplementary figures.}
    \subsection{Figure SI1: Concordance of four approaches for Differential expression analysis in single-cell RNA-seq when provided with either normalized read counts or transcript counts.}
    <<supplementary_figure_1a, eval = TRUE, fig.width = 4, fig.height = 4, fig.align="center">>=
      df3$class = '3relative'
    # only show new size normalization: 
    colnames(DEG_benchmark_df.1)[1:3] <- c('Precision', 'Recall', 'F1 score')
    ggplot(aes(factor(Type), value,  fill = data_type), data = melt(df3.1)) + geom_bar(position = position_dodge(), stat = 'identity') + #facet_wrap(~variable) + 
      ggtitle(title) + scale_fill_discrete('Type') + xlab('Type') + ylab('') + facet_wrap(~variable, scales = 'free_x') +  theme(axis.text.x = element_text(angle = 30, hjust = .9)) + 
      ggtitle('') + theme(strip.text.x = element_blank(), strip.text.y = element_blank()) + theme(strip.background = element_blank()) + xlab('')
    
    %def 
    
    <<supplementary_figure_1b, eval = TRUE, fig.width = 4, fig.height = 4, fig.align="center">>=
      qplot(variable, value, geom = 'bar', stat = 'identity', fill = variable, data = melt(overlap_df)) + xlab('') + ylab('number') + nm_theme() + theme(axis.text.x = element_text(angle = 30, hjust = .9))
    
    qplot(variable, value, geom = 'bar', stat = 'identity', fill = variable, data = melt(union_df)) + xlab('') + ylab('number') + nm_theme() + theme(axis.text.x = element_text(angle = 30, hjust = .9))
    %def 
    
    <<supplementary_figure_1c, eval = TRUE, fig.width = 4, fig.height = 4, fig.align="center">>=
      ggplot(aes(factor(Type), value,  fill = class), data = melt(umi_benchmark_df)) + geom_bar(position = position_dodge(), stat = 'identity') + #facet_wrap(~variable) + 
      ggtitle(title) + scale_fill_discrete('Type') + xlab('Type') + ylab('') + facet_wrap(~variable, scales = 'free_x') +  theme(axis.text.x = element_text(angle = 30, hjust = .9)) + 
      ggtitle('') + theme(strip.text.x = element_blank(), strip.text.y = element_blank()) + theme(strip.background = element_blank()) + nm_theme() + xlab('') + ylim(0, 1)
    %def 
    
    \subsection{Supplementary figures SI 2.}
    <<supplementary_figure_2a, eval = TRUE, fig.width = 4, fig.height = 4, fig.align="center">>=
      cds <- data.frame(transcript = round(as.vector(exprs(absolute_cds)[1:38919, c("SRR1033854_0", "SRR1033855_0", "SRR1033856_0")])), 
                        read_counts = as.vector(exprs(quake_read_cds)[1:38919, c("SRR1033854_0", "SRR1033855_0", "SRR1033856_0")]), 
                        cell = rep(c("SRR1033854_0", "SRR1033855_0", "SRR1033856_0"), each = 38919)
      )
    
    qplot(value, data = melt(cds), log = 'x') + geom_histogram(aes(fill = variable)) + facet_wrap(~cell+variable, nrow = 3, scale = 'free') + xlab('') + ylab('Gene number') +  theme(strip.background = element_blank(), strip.text.x = element_blank())+ nm_theme()
    
    %def 
    
    <<supplementary_figure_2b, eval = TRUE, fig.width = 4, fig.height = 4, fig.align="center">>=
      #generate the result of goodness of fit for each gene: 
      colnames(gd_fit_res_num)[1:2] <- c('NB', 'ZINB')
    test <- melt(gd_fit_res_num[, 1:3], id.vars = 'type')
    p1 <- qplot(as.factor(variable), as.numeric(value), geom = 'bar', stat = 'identity', data = test, fill = type) + facet_wrap('type') + nm_theme() + 
      theme(legend.position = 'none') + xlab('Fit types') + ylab('number of genes') + theme(strip.background = element_blank(),
                                                                                            strip.text.x = element_blank()) + theme(axis.text.x = element_text(angle = 30, hjust = .9))
    p1 + xlab('')
    @ %def
    
    <<supplementary_figure_2c, eval = TRUE>>=
      colnames(gd_fit_res_success_num)[1:2] <- c('NB', 'ZINB')
    test <- melt(gd_fit_res_success_num[, 1:3], id.vars = 'type')
    
    p2 <- qplot(as.factor(variable), as.numeric(value), geom = 'bar', stat = 'identity', data = test, fill = type) + facet_wrap('type') + nm_theme() + 
      theme(legend.position = 'none') + xlab('Fit types') + ylab('number of genes') + theme(strip.background = element_blank(),
                                                                                            strip.text.x = element_blank()) + theme(axis.text.x = element_text(angle = 30, hjust = .9))
    p2 + xlab('')
    @ %def
    
    \subsection{Supplementary figure 3: Single cell trajectory reconstruction using FPKM and transcript counts}
    <<supplementary_figure_3a, eval = TRUE, fig.width = 4, fig.height = 4>>=
      #run cole_muscle_ordering: 
      plot_spanning_tree(std_HSMM, color_by="Time", show_backbone=T, backbone_color = 'black',
                         markers=markers, show_cell_names = F, show_all_lineages = F, cell_size = 1, cell_link_size = 0.2) + nm_theme() #+ scale_size(range = c(0.5, .5)) 
    ggsave(paste(elife_directory, '/SI/eLife_figSI_fpkm_HSMM_tree.pdf', sep = ''), width = 1.5, height = 1.2)
    
    @ %def
    
    <<supplementary_figure_3b, eval = TRUE, fig.width = 4, fig.height = 4>>=
      #
      plot_spanning_tree(HSMM_myo, color_by="Time", show_backbone=T, backbone_color = 'black',
                         markers=markers, show_cell_names = F, show_all_lineages = F, cell_size = 1, cell_link_size = 0.2) + nm_theme() #+ scale_size(range = c(0.5, .5)) 
    ggsave(paste(elife_directory, '/SI/eLife_figSI_transcript_counts_HSMM_tree.pdf', sep = ''), width = 1.5, height = 1.2)
    @ %def
    
    <<supplementary_figure_3c, eval = TRUE, fig.width = 4, fig.height = 4>>=
      plot_tree_pairwise_cor2 <- function (std_tree_cds, absolute_tree_cds) 
      {
        maturation_df <- data.frame(cell = rep(colnames(std_tree_cds), 
                                               2), maturation_level = 100 * c(pData(std_tree_cds)$Pseudotime/max(pData(std_tree_cds)$Pseudotime), 
                                                                              pData(absolute_tree_cds)$Pseudotime/max(pData(absolute_tree_cds)$Pseudotime)), 
                                    Type = rep(c("FPKM", "Transcript counts (vst)"), each = ncol(std_tree_cds)), rownames = colnames(absolute_tree_cds))
        cor.coeff <- cor(pData(absolute_tree_cds)$Pseudotime, pData(std_tree_cds)$Pseudotime, 
                         method = "spearman")
        message(cor.coeff)
        p <- ggplot(aes(x = maturation_level, y = Type, group = cell), 
                    data = maturation_df) + geom_point(size = 1) + geom_line(color = "blue", alpha = .3) + 
          xlab("Pseudotime") + ylab("Type of tree construction") + monocle_theme_opts()
        return(p)
      }
    
    plot_tree_pairwise_cor2(std_HSMM, HSMM_myo) + nm_theme()
    ggsave(paste(elife_directory, '/SI/eLife_figSI_cmpr_tree.pdf', sep = ''), width = 4, height = 2)
    
    @ %def
    
    <<supplementary_figure_3d, eval = TRUE,  fig.width = 4, fig.height = 4>>=
      element_all <- c(row.names(HSMM_myo_size_norm_res[HSMM_myo_size_norm_res$qval <0.1, ]), 
                       row.names(std_HSMM_myo_pseudotime_res_ori[std_HSMM_myo_pseudotime_res_ori$qval <0.1, ]))
    sets_all <- c(rep(paste('Transcript counts (Size + VST)', sep = ''), nrow(HSMM_myo_size_norm_res[HSMM_myo_size_norm_res$qval <0.1, ])), 
                  rep(paste('FPKM', sep = ''), nrow(std_HSMM_myo_pseudotime_res_ori[std_HSMM_myo_pseudotime_res_ori$qval <0.1, ])))
    pdf(paste(elife_directory, '/SI/eLife_figSI_transcript_counts_HSMM_overlapping.pdf', sep = ''))
    venneuler_venn(element_all, sets_all)
    dev.off()
    table(sets_all) #number of genes
    @ %def
    
    <<supplementary_figure_3e, eval = TRUE, fig.width = 4, fig.height = 4>>=
      #first generate all the data for preparing the data.frame: 
      
      #figure 3e: 
      #only show absolute transcript counts data: 
      muscle_df$data_type = c("Transcript (size normalization)", "Transcript (size normalization)", "FPKM", "FPKM")
    
    muscle_df$class = '3relative'
    muscle_df.1 <- muscle_df
    muscle_df.1 <- muscle_df[1:2, ]
    qplot(factor(Type), value, stat = "identity", geom = 'bar', position = 'dodge', fill = I("red"), data = melt(muscle_df)) + #facet_wrap(~variable) + 
      ggtitle(title) + scale_fill_discrete('Type') + xlab('Type') + ylab('') + facet_wrap(~variable, scales = 'free_x') +  theme(axis.text.x = element_text(angle = 30, hjust = .9)) + 
      ggtitle('') + monocle_theme_opts() + theme(strip.text.x = element_blank(), strip.text.y = element_blank()) + theme(strip.background = element_blank())
    
    # muscle_df <- muscle_df[1:2, ] #select only the transcript counts data: 
    muscle_df[, 'Type'] <- c('Monocle', 'DESeq', 'DESeq', 'Monocle')
    colnames(muscle_df)[1:3] <- c('Precision', 'Recall', 'F1')
    qplot(factor(Type), value, stat = "identity", geom = 'bar', position = 'dodge', fill = data_type, data = melt(muscle_df), log = 'y') + #facet_wrap(~variable) + 
      ggtitle(title) + scale_fill_discrete('Type') + xlab('') + ylab('') + facet_wrap(~variable, scales = 'free_x') +  theme(axis.text.x = element_text(angle = 30, hjust = .9)) + 
      ggtitle('') + monocle_theme_opts() + theme(strip.text.x = element_blank(), strip.text.y = element_blank()) + theme(strip.background = element_blank()) + ylim(0, 1) + 
      theme(strip.background = element_blank(), strip.text.x = element_blank()) + nm_theme()
    
    # qplot(factor(Type), value, stat = "identity", geom = 'bar', position = 'dodge', fill = data_type, data = melt(muscle_df), log = 'y') + #facet_wrap(~variable) + 
    #     ggtitle(title) + scale_fill_discrete('Type') + xlab('') + ylab('') + facet_wrap(~variable, scales = 'free_x') +  theme(axis.text.x = element_text(angle = 30, hjust = .9)) + 
    #     ggtitle('') + monocle_theme_opts() + theme(strip.text.x = element_blank(), strip.text.y = element_blank()) + theme(strip.background = element_blank()) + ylim(0, 1) + 
    #     theme(strip.background = element_blank(), strip.text.x = element_blank()) 
    # ggsave(paste(elife_directory, '/SI/eLife_fig_si_pseudotime_test_help.pdf', sep = ''), width = 2.5, height = 1.5)
    @ %def
    
    \subsection{Supplementary figures SI 5.}
    <<supplementary_figure_2a, eval = TRUE, fig.width = 4, fig.height = 4, fig.align="center">>=
      #fraction of clusters in each biotype: 
      df <- data.frame(Time = pData(read_countdata_cds)$Time, sum_readcounts = esApply(read_countdata_cds[fData(read_countdata_cds)$biotype == 'spike', ], 2, sum))
    # qplot(sum_readcounts, fill = Time, log = 'x') + facet_wrap(~Time)
    qplot(sum_readcounts, fill = Time, log = 'x', data = df) + facet_wrap(~Time, ncol = 1, scales = 'free_y') + nm_theme() 
    %def 
    
    <<supplementary_figure_2b, eval=TRUE, fig.width = 4, fig.height = 4>>=
      #number of ERCC spike-in detected in each cell
      ercc_controls_detected_df <- data.frame(loss = esApply(ercc_controls, 2, function(x) sum(x > 0)), Time = pData(absolute_cds[, colnames(loss_ercc_spikein)])$Time)
    qplot(loss, fill = Time, data = ercc_controls_detected_df) + facet_wrap(~Time, ncol = 1) + nm_theme()
    %def 
    
    <<supplementary_figure_2c, eval=TRUE, fig.width = 4, fig.height = 4>>=
      Shalek_gene_df <- data.frame(experiment_name = pData(Shalek_read_countdata_cds[, c(colnames(Shalek_abs_subset_ko_LPS), colnames(Shalek_golgi_update))])$experiment_name, 
                                   sum_readcounts = esApply(Shalek_read_countdata_cds[, c(colnames(Shalek_abs_subset_ko_LPS), colnames(Shalek_golgi_update))], 2, sum))
    
    qplot(sum_readcounts, fill = experiment_name, log = 'x', data = Shalek_gene_df) + facet_wrap(~~experiment_name, ncol = 1, scales = 'free_y') + nm_theme() 
    
    %def 
    
    \section{Citation}
    If you use this package to analyze your experiments, please cite:
      <<citation, eval=TRUE>>=
      citation("xacHelper")
    @ %def 
    
    \section{Acknowledgements}
    We thank Yian Ma for technical discussions and Martin Kircher for cluster computation support. This work was supported by NIH Grant DP2 HD088158. C.T. is partly supported by a Dale. F. Frey Award for Breakthrough Scientists and an Alfred P. Sloan Foundation Research Fellowship. A. H. is supported by an NSF fellowship. 
    
    \section{Session Info}
    <<sessi>>=
      sessionInfo()
    @
      
      \bibliographystyle{unsrt}
    \bibliography{dev_tree}
    
    \end{document}