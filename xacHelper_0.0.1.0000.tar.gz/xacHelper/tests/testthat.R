library(testthat)
library(DevTree)

test_check("DevTree")
